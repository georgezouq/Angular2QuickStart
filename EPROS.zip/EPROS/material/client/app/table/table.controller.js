(function () {
    'use strict';

    angular.module('app.table')
        .controller('TableCtrl', ['$scope', '$filter', TableCtrl]);

    function TableCtrl($scope, $filter) {
        var init;

        $scope.stores = [];
        $scope.searchKeywords = '';
        $scope.filteredStores = [];
        $scope.row = '';
        $scope.select = select;
        $scope.onFilterChange = onFilterChange;
        $scope.onNumPerPageChange = onNumPerPageChange;
        $scope.onOrderChange = onOrderChange;
        $scope.search = search;
        $scope.order = order;
        $scope.numPerPageOpt = [3, 5, 10, 20];
        $scope.numPerPage = $scope.numPerPageOpt[2];
        $scope.currentPage = 1;
        $scope.currentPage = [];

        ////
        $scope.stores = [
            {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }
        ];

        function select(page) {
            var end, start;
            start = (page - 1) * $scope.numPerPage;
            end = start + $scope.numPerPage;
            return $scope.currentPageStores = $scope.filteredStores.slice(start, end);
        };

        function onFilterChange() {
            $scope.select(1);
            $scope.currentPage = 1;
            return $scope.row = '';
        };

        function onNumPerPageChange() {
            $scope.select(1);
            return $scope.currentPage = 1;
        };

        function onOrderChange() {
            $scope.select(1);
            return $scope.currentPage = 1;
        };

        function search() {
            $scope.filteredStores = $filter('filter')($scope.stores, $scope.searchKeywords);
            return $scope.onFilterChange();
        };

        function order(rowName) {
            if ($scope.row === rowName) {
            return;
            }
            $scope.row = rowName;
            $scope.filteredStores = $filter('orderBy')($scope.stores, rowName);
            return $scope.onOrderChange();
        };

        init = function() {
            $scope.search();
            return $scope.select($scope.currentPage);
        };

        init();
    }

})(); 