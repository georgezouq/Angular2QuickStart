(function () {
    'use strict';

    angular.module('app')
        .controller('DashboardCtrl', ['$scope', '$uibModal',DashboardCtrl])
        .controller('ModalTableCtrl', ['$scope', '$uibModal', '$log', ModalDemoCtrl])
        .controller('ModalTableInstanceCtrl', ['$scope', '$uibModalInstance', 'items','title', ModalInstanceCtrl])
        .controller('DashboardTableCtrl', ['$scope', '$filter', TableCtrl]);
        
	function TableCtrl($scope, $filter) {
        var init;

        $scope.stores = [];
        $scope.searchKeywords = '';
        $scope.filteredStores = [];
        $scope.row = '';
        $scope.select = select;
        $scope.onFilterChange = onFilterChange;
        $scope.onNumPerPageChange = onNumPerPageChange;
        $scope.onOrderChange = onOrderChange;
        $scope.search = search;
        $scope.order = order;
        $scope.numPerPageOpt = [3, 5, 10, 20];
        $scope.numPerPage = $scope.numPerPageOpt[2];
        $scope.currentPage = 1;
        $scope.currentPage = [];

        ////
        $scope.stores = [
            {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }, {
            name: '工业产品许可证核准流程',
            price: '处长',
            sales: '审批',
            rating: '市场准入',
            rule:'公司法',
            standard:'ISO9001',
            risk:'无'
            }
        ];

        function select(page) {
            var end, start;
            start = (page - 1) * $scope.numPerPage;
            end = start + $scope.numPerPage;
            return $scope.currentPageStores = $scope.filteredStores.slice(start, end);
        };

        function onFilterChange() {
            $scope.select(1);
            $scope.currentPage = 1;
            return $scope.row = '';
        };

        function onNumPerPageChange() {
            $scope.select(1);
            return $scope.currentPage = 1;
        };

        function onOrderChange() {
            $scope.select(1);
            return $scope.currentPage = 1;
        };

        function search() {
            $scope.filteredStores = $filter('filter')($scope.stores, $scope.searchKeywords);
            return $scope.onFilterChange();
        };

        function order(rowName) {
            if ($scope.row === rowName) {
            return;
            }
            $scope.row = rowName;
            $scope.filteredStores = $filter('orderBy')($scope.stores, rowName);
            return $scope.onOrderChange();
        };

        init = function() {
            $scope.search();
            return $scope.select($scope.currentPage);
        };

        init();
    }

	function ModalDemoCtrl($scope, $uibModal, $log) {
        $scope.items = ['item1XXX', 'item2', 'item3'];

        $scope.animationsEnabled = true;

        $scope.open = function (size,title) {
	        
 	        
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'myModalContent.html',
                controller: 'ModalTableInstanceCtrl',
                size: size,
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    title:function(){
	                    return title;
	                }
                    
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };

        $scope.toggleAnimation = function () {
            $scope.animationsEnabled = !$scope.animationsEnabled;
        };
    }

    function ModalInstanceCtrl($scope, $uibModalInstance, items,title) {
        $scope.items = items;

		$scope.modalTableTitle = title;

        $scope.selected = {
            item: $scope.items[0]
        };

        $scope.ok = function() {
            $uibModalInstance.close($scope.selected.item);
        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss("cancel");
        };

    }

    function DashboardCtrl($scope,$uiModal) {
        // success: #8BC34A 139,195,74
        // info: #00BCD4 0,188,212
        // gray: #EDF0F1 237,240,241  
		
        // Traffic chart
        $scope.combo = {};
        
        $scope.combo.options = {
            legend: {
                show: true,
                x: 'right',
                y: 'top',
                data: ['应用统计', '分析统计', '访问人数统计']
            },            
            grid: {
                x: 40,
                y: 60,
                x2: 40,
                y2: 30,
                borderWidth: 0
            },
            tooltip: {
                show: true,
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: $scope.color.gray
                    }
                }
            },            
            xAxis: [
                {
                    type : 'category',
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
	                    interval:0,
	                    formatter:function(val){
		                    val = val.length > 3 ? val.substring(0,3)+'..' : val;
		                    return val;
	                    },
                        textStyle: {
                            color: '#607685'
                        }
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            color: '#f3f3f3'
                        }
                    },
                    data : ['入职','离职','采购','报销','请假','调休', '涨薪','产品研发', '质量控制','测试','售后']
                }
            ],
            yAxis: [
                {
                    type : 'value',
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#607685'
                        }
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#f3f3f3'
                        }
                    }
                }
            ],
            series: [
                {
                    name:'应用统计',
                    type:'bar',
                    clickable: false,
                    itemStyle: {
                        normal: {
                            color: $scope.color.gray
                        },
                        emphasis: {
                            color: 'rgba(237,240,241,.7)'
                        }
                    },
                    barCategoryGap: '50%',
                    data:[75,62,45,60,73,90,31,56,70,63,58],
                    legendHoverLink: false,
                    z: 2
                },
                {
                    name:'分析统计',
                    type:'line',
                    smooth:true,
                    itemStyle: {
                        normal: {
                            color: $scope.color.success,
                            areaStyle: {
                                color: 'rgba(139,195,74,.7)',
                                type: 'default'
                            }
                        }
                    },
                    data:[0,5,20,15,30,28,40,28,25,5,0],
                    symbol: 'none',
                    legendHoverLink: false,
                    z: 3
                },
                {
                    name:'访问人数统计',
                    type:'line',
                    smooth:true,
                    itemStyle: {
                        normal: {
                            color: $scope.color.info,
                            areaStyle: {
                                color: 'rgba(0,188,212,.7)',
                                type: 'default'
                            }
                        }
                    },
                    data:[0,1,6,15,8,16,9,16,3,0],
                    symbol: 'none',
                    legendHoverLink: false,
                    z: 4
                }
            ]            
        };


        // 
        $scope.smline1 = {};
        $scope.smline2 = {};
        $scope.smline3 = {};
        $scope.smline4 = {};
        $scope.smline1.options = {
            tooltip: {
                show: false,
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: $scope.color.gray
                    }
                }
            }, 
            grid: {
                x: 1,
                y: 1,
                x2: 1,
                y2: 1,
                borderWidth: 0
            },            
            xAxis : [
                {
                    type : 'category',
                    show: false,
                    boundaryGap : false,
                    data : [1,2,3,4,5,6,7]
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    show: false,
                    axisLabel : {
                        formatter: '{value} °C'
                    }
                }
            ],
            series : [
                {
                    name:'*',
                    type:'line',
                    symbol: 'none',
                    data:[11, 11, 15, 13, 12, 13, 10],
                    itemStyle: {
                        normal: {
                            color: $scope.color.info
                        }
                    }                    
                }
            ]
        };
        $scope.smline2.options = {
            tooltip: {
                show: false,
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: $scope.color.gray
                    }
                }
            }, 
            grid: {
                x: 1,
                y: 1,
                x2: 1,
                y2: 1,
                borderWidth: 0
            },            
            xAxis : [
                {
                    type : 'category',
                    show: false,
                    boundaryGap : false,
                    data : [1,2,3,4,5,6,7]
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    show: false,
                    axisLabel : {
                        formatter: '{value} °C'
                    }
                }
            ],
            series : [
                {
                    name:'*',
                    type:'line',
                    symbol: 'none',
                    data:[11, 10, 14, 12, 13, 11, 12],
                    itemStyle: {
                        normal: {
                            color: $scope.color.success
                        }
                    }                     
                }
            ]
        };
        $scope.smline3.options = {
            tooltip: {
                show: false,
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: $scope.color.gray
                    }
                }
            }, 
            grid: {
                x: 1,
                y: 1,
                x2: 1,
                y2: 1,
                borderWidth: 0
            },            
            xAxis : [
                {
                    type : 'category',
                    show: false,
                    boundaryGap : false,
                    data : [1,2,3,4,5,6,7]
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    show: false,
                    axisLabel : {
                        formatter: '{value} °C'
                    }
                }
            ],
            series : [
                {
                    name:'*',
                    type:'line',
                    symbol: 'none',
                    data:[11, 10, 15, 13, 12, 13, 10],
                    itemStyle: {
                        normal: {
                            color: $scope.color.danger
                        }
                    }                 
                }
            ]
        };
        $scope.smline4.options = {
            tooltip: {
                show: false,
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: $scope.color.gray
                    }
                }
            }, 
            grid: {
                x: 1,
                y: 1,
                x2: 1,
                y2: 1,
                borderWidth: 0
            },            
            xAxis : [
                {
                    type : 'category',
                    show: false,
                    boundaryGap : false,
                    data : [1,2,3,4,5,6,7]
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    show: false,
                    axisLabel : {
                        formatter: '{value} °C'
                    }
                }
            ],
            series : [
                {
                    name:'*',
                    type:'line',
                    symbol: 'none',
                    data:[11, 12, 8, 10, 15, 12, 10],
                    itemStyle: {
                        normal: {
                            color: $scope.color.warning
                        }
                    }                      
                }
            ]
        };



        // Engagment pie charts
        var labelTop = {
            normal : {
                color: $scope.color.primary,
                label : {
                    show : true,
                    position : 'center',
                    formatter : '{b}',
                    textStyle: {
                        color: '#999',
                        baseline : 'top',
                        fontSize: 12
                    }
                },
                labelLine : {
                    show : false
                }
            }
        };
        var labelFromatter = {
            normal : {
                label : {
                    formatter : function (params){
                        return params.value + '天'
                    },
                    textStyle: {
                        color: $scope.color.text,
                        baseline : 'bottom',
                        fontSize: 20
                    }
                }
            },
        }
        var labelBottom = {
            normal : {
                color: '#f1f1f1',
                label : {
                    show : true,
                    position : 'center'
                },
                labelLine : {
                    show : false
                }
            }
        };        
        var radius = [55, 60];
        $scope.pie = {};
        $scope.pie.options = {
            series : [
                {
                    type : 'pie',
                    center : ['12.5%', '50%'],
                    radius : radius,
                    itemStyle : labelFromatter,
                    data : [
                        {name:'质量控制流程', value:80, itemStyle : labelTop},
                        {name:'other', value:20, itemStyle : labelBottom}
                    ]
                },{
                    type : 'pie',
                    center : ['37.5%', '50%'],
                    radius : radius,
                    itemStyle : labelFromatter,
                    data : [
                        {name:'产品发布流程', value:50, itemStyle : labelTop},
                        {name:'other', value:50, itemStyle : labelBottom}
                    ]
                },{
                    type : 'pie',
                    center : ['62.5%', '50%'],
                    radius : radius,
                    itemStyle : labelFromatter,
                    data : [
                        {name:'采购审批流程', value:20, itemStyle : labelTop},
                        {name:'other', value:80, itemStyle : labelBottom}
                    ]
                },{
                    type : 'pie',
                    center : ['87.5%', '50%'],
                    radius : radius,
                    itemStyle : labelFromatter,
                    data : [
                        {name:'请假流程', value:0, itemStyle : labelTop},
                        {name:'other', value:101, itemStyle : labelBottom}
                    ]
                }
            ]
        };        
    }


})(); 
